
DROP INDEX idx_career_steps_career_id;
DROP INDEX idx_career_interests_career_id;
DROP INDEX idx_career_skills_career_id;
DROP INDEX idx_assessment_responses_assessment_id;
DROP TABLE career_steps;
DROP TABLE career_interests;
DROP TABLE career_skills;
DROP TABLE careers;
DROP TABLE assessment_responses;
DROP TABLE assessments;
