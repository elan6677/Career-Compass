import { useNavigate } from "react-router";
import { Compass, Sparkles, TrendingUp, Target } from "lucide-react";
import { useEffect } from "react";

export default function Home() {
  const navigate = useNavigate();

  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700;800;900&family=Space+Grotesk:wght@300;400;500;600;700&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 via-purple-950 to-rose-950 relative overflow-hidden">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0">
          <div className="absolute top-10 left-10 w-96 h-96 bg-gradient-to-r from-purple-500/30 to-pink-500/30 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-10 right-10 w-[500px] h-[500px] bg-gradient-to-r from-indigo-500/30 to-cyan-500/30 rounded-full blur-3xl animate-pulse delay-1000" />
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-violet-500/20 to-fuchsia-500/20 rounded-full blur-3xl animate-pulse delay-2000" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent" />
        </div>

        <div className="relative max-w-7xl mx-auto px-6 py-20 sm:py-32">
          <div className="text-center">
            {/* Logo/Brand */}
            <div className="flex items-center justify-center mb-12">
              <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-400 via-pink-400 to-indigo-400 blur-2xl opacity-80 rounded-full animate-pulse" />
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-300 to-violet-400 blur-xl opacity-60 rounded-full animate-pulse delay-1000" />
                <div className="relative bg-gradient-to-br from-white/20 to-white/5 backdrop-blur-xl border border-white/30 rounded-3xl p-6 shadow-2xl group-hover:scale-110 transition-transform duration-500">
                  <Compass className="w-20 h-20 text-white drop-shadow-lg" strokeWidth={1.5} />
                </div>
              </div>
            </div>

            <h1 
              className="text-6xl sm:text-8xl lg:text-9xl font-black mb-8 bg-gradient-to-r from-white via-purple-200 via-pink-200 to-cyan-200 bg-clip-text text-transparent drop-shadow-2xl"
              style={{ 
                fontFamily: "'Playfair Display', serif",
                textShadow: '0 0 40px rgba(168, 85, 247, 0.4)'
              }}
            >
              CareerCompass
            </h1>

            <p className="text-xl sm:text-3xl text-white/90 mb-16 max-w-4xl mx-auto font-light leading-relaxed tracking-wide"
               style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Discover your <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent font-semibold">ideal career path</span> through intelligent analysis of your unique <span className="bg-gradient-to-r from-cyan-400 to-indigo-400 bg-clip-text text-transparent font-semibold">skills and passions</span>
            </p>

            <button
              onClick={() => navigate('/assessment')}
              className="group relative inline-flex items-center gap-4 px-12 py-6 text-xl font-bold text-white bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 rounded-full shadow-2xl hover:shadow-purple-500/60 transition-all duration-500 hover:scale-110 hover:-translate-y-1 border border-white/20 backdrop-blur-xl"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 rounded-full blur-lg opacity-50 group-hover:opacity-75 transition-opacity duration-500" />
              <span className="relative">Begin Your Journey</span>
              <Sparkles className="relative w-6 h-6 group-hover:rotate-12 group-hover:scale-110 transition-all duration-500" />
            </button>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-3 gap-12 mt-40">
            <div className="group relative">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/30 to-pink-600/30 rounded-3xl blur-2xl opacity-0 group-hover:opacity-100 transition-all duration-500" />
              <div className="relative bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-2xl border border-white/20 rounded-3xl p-10 hover:bg-white/15 hover:border-white/30 transition-all duration-500 hover:scale-105 hover:-translate-y-2 shadow-2xl">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-500 via-pink-500 to-indigo-500 rounded-3xl flex items-center justify-center mb-8 shadow-2xl shadow-purple-500/50 group-hover:scale-110 group-hover:rotate-3 transition-all duration-500">
                  <Target className="w-10 h-10 text-white drop-shadow-lg" />
                </div>
                <h3 className="text-3xl font-bold text-white mb-6" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Smart Assessment</h3>
                <p className="text-white/80 leading-relaxed text-lg">
                  Answer carefully designed questions about your skills and interests to build your unique profile
                </p>
              </div>
            </div>

            <div className="group relative">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-600/30 to-indigo-600/30 rounded-3xl blur-2xl opacity-0 group-hover:opacity-100 transition-all duration-500" />
              <div className="relative bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-2xl border border-white/20 rounded-3xl p-10 hover:bg-white/15 hover:border-white/30 transition-all duration-500 hover:scale-105 hover:-translate-y-2 shadow-2xl">
                <div className="w-20 h-20 bg-gradient-to-br from-cyan-500 via-blue-500 to-indigo-500 rounded-3xl flex items-center justify-center mb-8 shadow-2xl shadow-cyan-500/50 group-hover:scale-110 group-hover:rotate-3 transition-all duration-500">
                  <Sparkles className="w-10 h-10 text-white drop-shadow-lg" />
                </div>
                <h3 className="text-3xl font-bold text-white mb-6" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>AI-Powered Matching</h3>
                <p className="text-white/80 leading-relaxed text-lg">
                  Advanced algorithms analyze your responses to find careers perfectly aligned with your strengths
                </p>
              </div>
            </div>

            <div className="group relative">
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-600/30 to-teal-600/30 rounded-3xl blur-2xl opacity-0 group-hover:opacity-100 transition-all duration-500" />
              <div className="relative bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-2xl border border-white/20 rounded-3xl p-10 hover:bg-white/15 hover:border-white/30 transition-all duration-500 hover:scale-105 hover:-translate-y-2 shadow-2xl">
                <div className="w-20 h-20 bg-gradient-to-br from-emerald-500 via-teal-500 to-green-500 rounded-3xl flex items-center justify-center mb-8 shadow-2xl shadow-emerald-500/50 group-hover:scale-110 group-hover:rotate-3 transition-all duration-500">
                  <TrendingUp className="w-10 h-10 text-white drop-shadow-lg" />
                </div>
                <h3 className="text-3xl font-bold text-white mb-6" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Development Plan</h3>
                <p className="text-white/80 leading-relaxed text-lg">
                  Receive a personalized roadmap with actionable steps to achieve your career goals
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="relative border-t border-white/20 bg-gradient-to-r from-black/20 to-transparent backdrop-blur-xl py-12">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-white/60 text-lg font-light" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Built to help students discover their perfect career path with confidence
          </p>
        </div>
      </div>
    </div>
  );
}
