import { useLocation, useNavigate } from "react-router";
import { ArrowRight, TrendingUp, Briefcase, DollarSign } from "lucide-react";
import { CareerMatch } from "@/shared/types";
import { useEffect } from "react";

export default function Results() {
  const location = useLocation();
  const navigate = useNavigate();
  const matches: CareerMatch[] = location.state?.matches || [];

  useEffect(() => {
    if (matches.length === 0) {
      navigate('/');
    }
  }, [matches, navigate]);

  if (matches.length === 0) {
    return null;
  }

  const getMatchColor = (score: number) => {
    if (score >= 80) return 'from-emerald-500 to-green-500';
    if (score >= 60) return 'from-blue-500 to-cyan-500';
    return 'from-purple-500 to-indigo-500';
  };

  const getMatchLabel = (score: number) => {
    if (score >= 80) return 'Excellent Match';
    if (score >= 60) return 'Good Match';
    return 'Potential Match';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 via-purple-950 to-rose-950 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-96 h-96 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-10 right-10 w-[500px] h-[500px] bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full blur-3xl animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-indigo-500/15 to-cyan-500/15 rounded-full blur-3xl animate-pulse delay-2000" />
      </div>
      <div className="relative max-w-7xl mx-auto px-6 py-16">
        {/* Header */}
        <div className="text-center mb-20">
          <div className="inline-flex items-center gap-3 bg-gradient-to-r from-emerald-500/30 to-teal-500/30 backdrop-blur-2xl border border-emerald-400/40 rounded-full px-8 py-3 mb-8 shadow-2xl">
            <div className="w-8 h-8 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-white" />
            </div>
            <span className="text-base font-bold text-emerald-200" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Analysis Complete</span>
          </div>
          
          <h1 className="text-5xl sm:text-8xl font-black text-white mb-6 bg-gradient-to-r from-white via-emerald-200 to-teal-200 bg-clip-text text-transparent"
              style={{ fontFamily: "'Playfair Display', serif" }}>
            Your Career Matches
          </h1>
          <p className="text-xl text-white/80 max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Based on your unique skills and interests, here are the careers best suited for you
          </p>
        </div>

        {/* Top Match Highlight */}
        <div className="mb-16">
          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/40 to-teal-500/40 rounded-3xl blur-2xl opacity-90" />
            <div className="relative bg-gradient-to-br from-white/15 to-white/10 backdrop-blur-2xl border border-white/30 rounded-3xl p-12 hover:border-emerald-400/60 hover:bg-white/20 transition-all duration-500 hover:scale-[1.02] hover:-translate-y-2 shadow-2xl">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <div className="inline-flex items-center gap-2 bg-gradient-to-r from-emerald-500/30 to-teal-500/30 border border-emerald-400/40 rounded-full px-6 py-2 mb-4 shadow-xl">
                    <span className="text-sm font-black text-emerald-200" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>TOP MATCH</span>
                  </div>
                  <h2 className="text-4xl font-black text-white mb-4" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{matches[0].title}</h2>
                  <p className="text-white/80 leading-relaxed text-lg">{matches[0].description}</p>
                </div>
                <div className="text-right">
                  <div className="text-6xl font-black bg-gradient-to-r from-emerald-300 via-teal-300 to-green-300 bg-clip-text text-transparent mb-2 drop-shadow-xl">
                    {matches[0].match_score}%
                  </div>
                  <div className="text-base text-emerald-200 font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Match Score</div>
                </div>
              </div>

              <div className="grid sm:grid-cols-3 gap-6 mb-8">
                <div className="bg-gradient-to-br from-white/15 to-white/10 rounded-2xl p-6 border border-white/20 backdrop-blur-xl shadow-xl hover:bg-white/20 transition-all duration-300">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-xl flex items-center justify-center mb-3 shadow-lg">
                    <Briefcase className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-sm text-white/60 mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Category</div>
                  <div className="text-lg font-bold text-white">{matches[0].category}</div>
                </div>
                <div className="bg-gradient-to-br from-white/15 to-white/10 rounded-2xl p-6 border border-white/20 backdrop-blur-xl shadow-xl hover:bg-white/20 transition-all duration-300">
                  <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center mb-3 shadow-lg">
                    <DollarSign className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-sm text-white/60 mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Salary Range</div>
                  <div className="text-lg font-bold text-white">{matches[0].salary_range}</div>
                </div>
                <div className="bg-gradient-to-br from-white/15 to-white/10 rounded-2xl p-6 border border-white/20 backdrop-blur-xl shadow-xl hover:bg-white/20 transition-all duration-300">
                  <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-xl flex items-center justify-center mb-3 shadow-lg">
                    <TrendingUp className="w-5 h-5 text-white" />
                  </div>
                  <div className="text-sm text-white/60 mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Job Growth</div>
                  <div className="text-lg font-bold text-white">{matches[0].growth_outlook}</div>
                </div>
              </div>

              <button
                onClick={() => navigate(`/career/${matches[0].id}`)}
                className="group w-full flex items-center justify-center gap-3 px-8 py-6 text-xl font-bold text-white bg-gradient-to-r from-emerald-600 via-teal-600 to-green-600 rounded-2xl hover:shadow-2xl hover:shadow-emerald-500/60 transition-all duration-500 hover:scale-105 hover:-translate-y-1 border border-white/20"
                style={{ fontFamily: "'Space Grotesk', sans-serif" }}
              >
                <span>View Development Plan</span>
                <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform duration-300" />
              </button>
            </div>
          </div>
        </div>

        {/* Other Matches */}
        <h2 className="text-3xl font-black text-white mb-8" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Other Great Matches</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {matches.slice(1).map((match) => (
            <div
              key={match.id}
              className="group relative cursor-pointer"
              onClick={() => navigate(`/career/${match.id}`)}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/30 to-indigo-500/30 rounded-2xl blur-2xl opacity-0 group-hover:opacity-100 transition-all duration-500" />
              <div className="relative bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-2xl border border-white/20 rounded-3xl p-8 hover:bg-white/15 hover:border-white/30 transition-all duration-500 hover:scale-105 hover:-translate-y-2 shadow-2xl">
                <div className="flex items-start justify-between mb-6">
                  <div className={`text-4xl font-black bg-gradient-to-r ${getMatchColor(match.match_score)} bg-clip-text text-transparent drop-shadow-lg`}>
                    {match.match_score}%
                  </div>
                  <div className="text-sm font-bold text-white/80 bg-gradient-to-r from-purple-500/30 to-indigo-500/30 border border-purple-400/40 rounded-full px-4 py-2 backdrop-blur-xl">
                    {getMatchLabel(match.match_score)}
                  </div>
                </div>

                <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-purple-200 transition-colors" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  {match.title}
                </h3>
                <p className="text-base text-white/70 mb-6 line-clamp-2 leading-relaxed">{match.description}</p>

                <div className="flex items-center gap-3 text-sm text-white/60 mb-6">
                  <div className="w-6 h-6 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-lg flex items-center justify-center">
                    <Briefcase className="w-3 h-3 text-white" />
                  </div>
                  <span style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{match.category}</span>
                </div>

                <div className="pt-6 border-t border-white/20 flex items-center justify-between text-sm">
                  <div className="flex flex-col items-center">
                    <span className="text-white/60 mb-1">Skills</span>
                    <span className="text-white font-bold text-lg">{match.skill_match}%</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <span className="text-white/60 mb-1">Interests</span>
                    <span className="text-white font-bold text-lg">{match.interest_match}%</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-2 px-8 py-4 text-white bg-white/10 backdrop-blur-xl border border-white/20 rounded-full hover:bg-white/20 transition-all duration-200 font-medium"
          >
            Start New Assessment
          </button>
        </div>
      </div>
    </div>
  );
}
