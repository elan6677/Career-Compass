import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router";
import { 
  ArrowLeft, 
  Briefcase, 
  DollarSign, 
  TrendingUp, 
  GraduationCap, 
  CheckCircle2,
  Sparkles,
  Clock
} from "lucide-react";
import { CareerDetail } from "@/shared/types";

export default function CareerDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [career, setCareer] = useState<CareerDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCareer = async () => {
      try {
        const response = await fetch(`/api/careers/${id}`);
        if (response.ok) {
          const data = await response.json();
          setCareer(data);
        }
      } catch (error) {
        console.error('Error fetching career:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCareer();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-900 to-violet-950 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-purple-300/30 border-t-purple-300 rounded-full animate-spin" />
      </div>
    );
  }

  if (!career) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-900 to-violet-950 flex items-center justify-center">
        <div className="text-center">
          <p className="text-white text-xl mb-4">Career not found</p>
          <button
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200"
          >
            Return to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 via-purple-950 to-rose-950 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-10 right-10 w-80 h-80 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-gradient-to-r from-indigo-500/20 to-cyan-500/20 rounded-full blur-3xl animate-pulse delay-1000" />
        <div className="absolute top-1/3 right-1/3 w-64 h-64 bg-gradient-to-r from-emerald-500/15 to-teal-500/15 rounded-full blur-3xl animate-pulse delay-2000" />
      </div>
      <div className="relative max-w-6xl mx-auto px-6 py-16">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="group flex items-center gap-3 text-white/80 hover:text-white transition-all duration-300 mb-12 bg-white/10 backdrop-blur-xl border border-white/20 rounded-full px-6 py-3 hover:bg-white/20 hover:scale-105 shadow-xl"
          style={{ fontFamily: "'Space Grotesk', sans-serif" }}
        >
          <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform duration-300" />
          <span className="font-semibold">Back to Results</span>
        </button>

        {/* Header */}
        <div className="relative mb-16">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-500/30 to-indigo-500/30 rounded-3xl blur-2xl opacity-90" />
          <div className="relative bg-gradient-to-br from-white/15 to-white/10 backdrop-blur-2xl border border-white/30 rounded-3xl p-12 shadow-2xl hover:bg-white/20 transition-all duration-500">
            <div className="flex items-start justify-between mb-8">
              <div>
                <div className="inline-flex items-center gap-3 bg-gradient-to-r from-purple-500/30 to-indigo-500/30 border border-purple-400/40 rounded-full px-6 py-2 mb-6 shadow-xl">
                  <div className="w-6 h-6 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-full flex items-center justify-center">
                    <Briefcase className="w-3 h-3 text-white" />
                  </div>
                  <span className="text-base font-bold text-purple-200" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{career.category}</span>
                </div>
                <h1 className="text-5xl sm:text-7xl font-black text-white mb-6 bg-gradient-to-r from-white via-purple-200 to-indigo-200 bg-clip-text text-transparent"
                    style={{ fontFamily: "'Playfair Display', serif" }}>{career.title}</h1>
                <p className="text-xl text-white/80 leading-relaxed max-w-4xl" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{career.description}</p>
              </div>
            </div>

            <div className="grid sm:grid-cols-3 gap-8">
              <div className="group bg-gradient-to-br from-white/15 to-white/10 rounded-2xl p-8 border border-white/20 backdrop-blur-xl shadow-xl hover:bg-white/20 hover:border-white/30 transition-all duration-500 hover:scale-105 hover:-translate-y-1">
                <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-2xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <DollarSign className="w-6 h-6 text-white" />
                </div>
                <div className="text-sm text-white/60 mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Salary Range</div>
                <div className="text-xl font-bold text-white">{career.salary_range}</div>
              </div>
              <div className="group bg-gradient-to-br from-white/15 to-white/10 rounded-2xl p-8 border border-white/20 backdrop-blur-xl shadow-xl hover:bg-white/20 hover:border-white/30 transition-all duration-500 hover:scale-105 hover:-translate-y-1">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <div className="text-sm text-white/60 mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Job Growth</div>
                <div className="text-xl font-bold text-white">{career.growth_outlook}</div>
              </div>
              <div className="group bg-gradient-to-br from-white/15 to-white/10 rounded-2xl p-8 border border-white/20 backdrop-blur-xl shadow-xl hover:bg-white/20 hover:border-white/30 transition-all duration-500 hover:scale-105 hover:-translate-y-1">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-2xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <GraduationCap className="w-6 h-6 text-white" />
                </div>
                <div className="text-sm text-white/60 mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Education</div>
                <div className="text-lg font-bold text-white leading-tight">{career.education_required}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Skills */}
          <div className="bg-gradient-to-br from-white/15 to-white/10 backdrop-blur-2xl border border-white/20 rounded-3xl p-8 shadow-2xl hover:bg-white/20 transition-all duration-500">
            <h2 className="text-3xl font-bold text-white mb-8 flex items-center gap-3" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              Key Skills
            </h2>
            <div className="space-y-6">
              {career.skills
                .sort((a, b) => b.importance - a.importance)
                .map((skill, index) => (
                  <div key={index} className="group flex items-center gap-4 p-4 bg-white/10 rounded-2xl border border-white/20 hover:bg-white/15 hover:border-white/30 transition-all duration-300">
                    <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                      <span className="text-white text-lg font-bold">{skill.importance}</span>
                    </div>
                    <div className="flex-1">
                      <div className="text-white font-bold text-lg mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{skill.skill_name}</div>
                      <div className="w-full bg-white/20 rounded-full h-3">
                        <div
                          className="bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 h-3 rounded-full transition-all duration-700 shadow-lg"
                          style={{ width: `${(skill.importance / 5) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>

          {/* Interests */}
          <div className="bg-gradient-to-br from-white/15 to-white/10 backdrop-blur-2xl border border-white/20 rounded-3xl p-8 shadow-2xl hover:bg-white/20 transition-all duration-500">
            <h2 className="text-3xl font-bold text-white mb-8 flex items-center gap-3" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-cyan-500 rounded-2xl flex items-center justify-center shadow-lg">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              Related Interests
            </h2>
            <div className="space-y-6">
              {career.interests
                .sort((a, b) => b.importance - a.importance)
                .map((interest, index) => (
                  <div key={index} className="group flex items-center gap-4 p-4 bg-white/10 rounded-2xl border border-white/20 hover:bg-white/15 hover:border-white/30 transition-all duration-300">
                    <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-indigo-500 to-cyan-500 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                      <span className="text-white text-lg font-bold">{interest.importance}</span>
                    </div>
                    <div className="flex-1">
                      <div className="text-white font-bold text-lg mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{interest.interest_name}</div>
                      <div className="w-full bg-white/20 rounded-full h-3">
                        <div
                          className="bg-gradient-to-r from-indigo-500 via-cyan-500 to-purple-500 h-3 rounded-full transition-all duration-700 shadow-lg"
                          style={{ width: `${(interest.importance / 5) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>

        {/* Development Plan */}
        <div className="bg-gradient-to-br from-white/15 to-white/10 backdrop-blur-2xl border border-white/30 rounded-3xl p-12 shadow-2xl">
          <h2 className="text-4xl font-black text-white mb-4" style={{ fontFamily: "'Space Grotesk', serif" }}>Your Development Plan</h2>
          <p className="text-xl text-white/80 mb-12 leading-relaxed">Follow these steps to build your career with confidence</p>

          <div className="space-y-8">
            {career.steps.map((step, index) => (
              <div key={index} className="relative group">
                {index < career.steps.length - 1 && (
                  <div className="absolute left-6 top-16 bottom-0 w-1 bg-gradient-to-b from-purple-500 via-pink-500 to-indigo-500 rounded-full shadow-lg" />
                )}
                <div className="flex gap-6">
                  <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-purple-600 via-pink-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-purple-500/60 relative z-10 group-hover:scale-110 group-hover:rotate-3 transition-all duration-500">
                    <CheckCircle2 className="w-7 h-7 text-white" />
                  </div>
                  <div className="flex-1 bg-gradient-to-br from-white/15 to-white/10 border border-white/20 rounded-2xl p-8 hover:bg-white/20 hover:border-white/30 transition-all duration-500 hover:scale-[1.02] hover:-translate-y-1 shadow-xl">
                    <div className="flex items-start justify-between mb-4">
                      <h3 className="text-2xl font-bold text-white" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{step.title}</h3>
                      {step.timeframe && (
                        <div className="flex items-center gap-2 text-white/80 text-sm bg-gradient-to-r from-purple-500/30 to-indigo-500/30 border border-purple-400/40 rounded-full px-4 py-2 backdrop-blur-xl shadow-lg">
                          <Clock className="w-4 h-4" />
                          <span className="font-semibold">{step.timeframe}</span>
                        </div>
                      )}
                    </div>
                    <p className="text-white/80 leading-relaxed text-lg">{step.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <button
            onClick={() => navigate('/')}
            className="group inline-flex items-center gap-3 px-12 py-6 text-xl font-bold text-white bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 rounded-full hover:shadow-2xl hover:shadow-purple-500/60 transition-all duration-500 hover:scale-110 hover:-translate-y-1 border border-white/20 backdrop-blur-xl"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            <span>Explore Other Careers</span>
            <Sparkles className="w-6 h-6 group-hover:rotate-12 group-hover:scale-110 transition-all duration-500" />
          </button>
        </div>
      </div>
    </div>
  );
}
