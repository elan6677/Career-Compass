import { useState } from "react";
import { useNavigate } from "react-router";
import { ChevronRight, ChevronLeft, Sparkles } from "lucide-react";
import AssessmentQuestion from "@/react-app/components/AssessmentQuestion";
import { skillQuestions, interestQuestions } from "@/react-app/data/questions";
import { AssessmentResponse } from "@/shared/types";

export default function Assessment() {
  const navigate = useNavigate();
  const [currentSection, setCurrentSection] = useState<'skills' | 'interests'>('skills');
  const [skillResponses, setSkillResponses] = useState<Map<string, number>>(new Map());
  const [interestResponses, setInterestResponses] = useState<Map<string, number>>(new Map());
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSkillResponse = (skillId: string, value: number) => {
    setSkillResponses(new Map(skillResponses.set(skillId, value)));
  };

  const handleInterestResponse = (interestId: string, value: number) => {
    setInterestResponses(new Map(interestResponses.set(interestId, value)));
  };

  const canProceedToInterests = skillResponses.size === skillQuestions.length;
  const canSubmit = interestResponses.size === interestQuestions.length;

  const handleSubmit = async () => {
    if (!canSubmit) return;

    setIsSubmitting(true);

    const responses: AssessmentResponse[] = [
      ...Array.from(skillResponses.entries()).map(([question_id, response_value]) => ({
        question_type: 'skill' as const,
        question_id,
        response_value,
      })),
      ...Array.from(interestResponses.entries()).map(([question_id, response_value]) => ({
        question_type: 'interest' as const,
        question_id,
        response_value,
      })),
    ];

    try {
      const response = await fetch('/api/careers/match', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ responses }),
      });

      if (response.ok) {
        const matches = await response.json();
        navigate('/results', { state: { matches } });
      }
    } catch (error) {
      console.error('Error submitting assessment:', error);
      setIsSubmitting(false);
    }
  };

  const progressPercentage = currentSection === 'skills'
    ? (skillResponses.size / skillQuestions.length) * 50
    : 50 + (interestResponses.size / interestQuestions.length) * 50;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 via-purple-950 to-rose-950 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-10 right-10 w-80 h-80 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-gradient-to-r from-indigo-500/20 to-cyan-500/20 rounded-full blur-3xl animate-pulse delay-1000" />
        <div className="absolute top-1/3 left-1/3 w-64 h-64 bg-gradient-to-r from-violet-500/15 to-fuchsia-500/15 rounded-full blur-3xl animate-pulse delay-2000" />
      </div>
      {/* Progress Bar */}
      <div className="fixed top-0 left-0 right-0 h-2 bg-black/20 backdrop-blur-xl z-50 border-b border-white/10">
        <div
          className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 transition-all duration-500 shadow-lg shadow-purple-500/50"
          style={{ width: `${progressPercentage}%` }}
        />
      </div>

      <div className="relative max-w-5xl mx-auto px-6 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-3 bg-gradient-to-r from-white/15 to-white/10 backdrop-blur-2xl border border-white/30 rounded-full px-8 py-3 mb-8 shadow-2xl">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="text-base font-semibold text-white" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              {currentSection === 'skills' ? 'Step 1 of 2: Skills Assessment' : 'Step 2 of 2: Interests Assessment'}
            </span>
          </div>
          
          <h1 className="text-5xl sm:text-7xl font-black text-white mb-6 bg-gradient-to-r from-white via-purple-200 to-pink-200 bg-clip-text text-transparent"
              style={{ fontFamily: "'Playfair Display', serif" }}>
            {currentSection === 'skills' ? 'Rate Your Skills' : 'Rate Your Interests'}
          </h1>
          <p className="text-xl text-white/80 max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            {currentSection === 'skills'
              ? 'How confident are you with each of these skills? Be honest - there are no right or wrong answers.'
              : 'How interested are you in each of these areas? Your genuine interests matter most.'}
          </p>
        </div>

        {/* Questions */}
        <div className="space-y-8 mb-16">
          {currentSection === 'skills' ? (
            skillQuestions.map((question) => (
              <AssessmentQuestion
                key={question.id}
                question={question.skill}
                description={question.description}
                value={skillResponses.get(question.id) || 0}
                onChange={(value) => handleSkillResponse(question.id, value)}
              />
            ))
          ) : (
            interestQuestions.map((question) => (
              <AssessmentQuestion
                key={question.id}
                question={question.interest}
                description={question.description}
                value={interestResponses.get(question.id) || 0}
                onChange={(value) => handleInterestResponse(question.id, value)}
              />
            ))
          )}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between gap-6">
          {currentSection === 'interests' && (
            <button
              onClick={() => setCurrentSection('skills')}
              className="group flex items-center gap-3 px-8 py-4 text-white bg-gradient-to-r from-white/15 to-white/10 backdrop-blur-2xl border border-white/30 rounded-full hover:bg-white/25 hover:border-white/40 transition-all duration-300 hover:scale-105 shadow-xl"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform duration-300" />
              <span className="font-semibold">Back to Skills</span>
            </button>
          )}

          {currentSection === 'skills' ? (
            <button
              onClick={() => setCurrentSection('interests')}
              disabled={!canProceedToInterests}
              className={`ml-auto group flex items-center gap-3 px-10 py-5 text-xl font-bold rounded-full transition-all duration-300 shadow-2xl ${
                canProceedToInterests
                  ? 'text-white bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 hover:shadow-purple-500/60 hover:scale-110 hover:-translate-y-1 border border-white/20'
                  : 'text-white/40 bg-white/5 cursor-not-allowed border border-white/10'
              }`}
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              <span>Continue to Interests</span>
              <ChevronRight className="w-6 h-6 group-hover:translate-x-1 transition-transform duration-300" />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={!canSubmit || isSubmitting}
              className={`ml-auto group flex items-center gap-3 px-10 py-5 text-xl font-bold rounded-full transition-all duration-300 shadow-2xl ${
                canSubmit && !isSubmitting
                  ? 'text-white bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 hover:shadow-purple-500/60 hover:scale-110 hover:-translate-y-1 border border-white/20'
                  : 'text-white/40 bg-white/5 cursor-not-allowed border border-white/10'
              }`}
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              {isSubmitting ? (
                <>
                  <div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Analyzing...</span>
                </>
              ) : (
                <>
                  <span>See My Matches</span>
                  <Sparkles className="w-6 h-6 group-hover:rotate-12 group-hover:scale-110 transition-all duration-300" />
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
