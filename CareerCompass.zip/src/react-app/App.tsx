import { BrowserRouter as Router, Routes, Route } from "react-router";
import HomePage from "@/react-app/pages/Home";
import AssessmentPage from "@/react-app/pages/Assessment";
import ResultsPage from "@/react-app/pages/Results";
import CareerDetailPage from "@/react-app/pages/CareerDetail";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/assessment" element={<AssessmentPage />} />
        <Route path="/results" element={<ResultsPage />} />
        <Route path="/career/:id" element={<CareerDetailPage />} />
      </Routes>
    </Router>
  );
}
