import { Star } from "lucide-react";

interface AssessmentQuestionProps {
  question: string;
  description: string;
  value: number;
  onChange: (value: number) => void;
}

export default function AssessmentQuestion({ question, description, value, onChange }: AssessmentQuestionProps) {
  const ratings = [
    { value: 1, label: "Not at all" },
    { value: 2, label: "Slightly" },
    { value: 3, label: "Moderately" },
    { value: 4, label: "Very" },
    { value: 5, label: "Extremely" },
  ];

  return (
    <div className="group bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-2xl border border-white/20 rounded-3xl p-8 hover:bg-white/15 hover:border-white/30 transition-all duration-500 hover:scale-[1.02] hover:-translate-y-1 shadow-2xl">
      <h3 className="text-2xl font-bold text-white mb-3" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{question}</h3>
      <p className="text-white/70 mb-8 text-base leading-relaxed">{description}</p>
      
      <div className="flex flex-col sm:flex-row gap-4">
        {ratings.map((rating) => (
          <button
            key={rating.value}
            onClick={() => onChange(rating.value)}
            className={`flex-1 flex flex-col items-center gap-3 py-6 px-4 rounded-2xl border-2 transition-all duration-300 group ${
              value === rating.value
                ? "bg-gradient-to-br from-purple-600 via-pink-600 to-indigo-600 border-purple-400 shadow-2xl shadow-purple-500/60 scale-110 -translate-y-2"
                : "bg-white/10 border-white/20 hover:border-purple-400/60 hover:bg-white/20 hover:scale-105 hover:-translate-y-1"
            }`}
          >
            <div className="flex gap-1.5">
              {[...Array(rating.value)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-5 h-5 transition-all duration-300 ${
                    value === rating.value 
                      ? "fill-white text-white drop-shadow-lg" 
                      : "fill-purple-400 text-purple-400 group-hover:fill-purple-300 group-hover:text-purple-300"
                  }`}
                />
              ))}
            </div>
            <span className={`text-sm font-semibold transition-all duration-300 ${
              value === rating.value ? "text-white" : "text-white/80"
            }`} style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              {rating.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
