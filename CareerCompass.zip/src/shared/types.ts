import z from "zod";

// Assessment schemas
export const AssessmentResponseSchema = z.object({
  question_type: z.enum(['skill', 'interest']),
  question_id: z.string(),
  response_value: z.number().int().min(1).max(5),
});

export const SubmitAssessmentSchema = z.object({
  responses: z.array(AssessmentResponseSchema),
});

export type AssessmentResponse = z.infer<typeof AssessmentResponseSchema>;
export type SubmitAssessment = z.infer<typeof SubmitAssessmentSchema>;

// Career schemas
export const CareerMatchSchema = z.object({
  id: z.number(),
  title: z.string(),
  description: z.string(),
  category: z.string(),
  salary_range: z.string().nullable(),
  growth_outlook: z.string().nullable(),
  education_required: z.string().nullable(),
  match_score: z.number(),
  skill_match: z.number(),
  interest_match: z.number(),
});

export type CareerMatch = z.infer<typeof CareerMatchSchema>;

export const CareerDetailSchema = z.object({
  id: z.number(),
  title: z.string(),
  description: z.string(),
  category: z.string(),
  salary_range: z.string().nullable(),
  growth_outlook: z.string().nullable(),
  education_required: z.string().nullable(),
  skills: z.array(z.object({
    skill_name: z.string(),
    importance: z.number(),
  })),
  interests: z.array(z.object({
    interest_name: z.string(),
    importance: z.number(),
  })),
  steps: z.array(z.object({
    step_order: z.number(),
    title: z.string(),
    description: z.string(),
    timeframe: z.string().nullable(),
  })),
});

export type CareerDetail = z.infer<typeof CareerDetailSchema>;

// Assessment question types
export interface SkillQuestion {
  id: string;
  skill: string;
  description: string;
}

export interface InterestQuestion {
  id: string;
  interest: string;
  description: string;
}
