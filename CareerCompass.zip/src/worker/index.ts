import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { SubmitAssessmentSchema } from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

// Get career matches based on assessment responses
app.post("/api/careers/match", zValidator("json", SubmitAssessmentSchema), async (c) => {
  const { responses } = c.req.valid("json");
  const db = c.env.DB;

  // Calculate user's skill and interest profiles
  const skillScores = new Map<string, number>();
  const interestScores = new Map<string, number>();

  responses.forEach((response) => {
    if (response.question_type === 'skill') {
      skillScores.set(response.question_id, response.response_value);
    } else {
      interestScores.set(response.question_id, response.response_value);
    }
  });

  // Get all careers with their skills and interests
  const careers = await db.prepare(`
    SELECT id, title, description, category, salary_range, growth_outlook, education_required
    FROM careers
  `).all();

  const careerMatches = [];

  for (const career of careers.results) {
    // Get career skills
    const careerSkills = await db.prepare(`
      SELECT skill_name, importance FROM career_skills WHERE career_id = ?
    `).bind(career.id).all();

    // Get career interests
    const careerInterests = await db.prepare(`
      SELECT interest_name, importance FROM career_interests WHERE career_id = ?
    `).bind(career.id).all();

    // Calculate skill match score
    let skillMatchScore = 0;
    let skillMaxScore = 0;
    for (const cs of careerSkills.results) {
      const skillName = (cs as { skill_name: string }).skill_name;
      const importance = (cs as { importance: number }).importance;
      const userScore = skillScores.get(skillName) || 0;
      skillMatchScore += userScore * importance;
      skillMaxScore += 5 * importance;
    }
    const skillMatch = skillMaxScore > 0 ? (skillMatchScore / skillMaxScore) * 100 : 0;

    // Calculate interest match score
    let interestMatchScore = 0;
    let interestMaxScore = 0;
    for (const ci of careerInterests.results) {
      const interestName = (ci as { interest_name: string }).interest_name;
      const importance = (ci as { importance: number }).importance;
      const userScore = interestScores.get(interestName) || 0;
      interestMatchScore += userScore * importance;
      interestMaxScore += 5 * importance;
    }
    const interestMatch = interestMaxScore > 0 ? (interestMatchScore / interestMaxScore) * 100 : 0;

    // Overall match is weighted average (60% skill, 40% interest)
    const matchScore = (skillMatch * 0.6) + (interestMatch * 0.4);

    careerMatches.push({
      id: career.id,
      title: career.title,
      description: career.description,
      category: career.category,
      salary_range: career.salary_range,
      growth_outlook: career.growth_outlook,
      education_required: career.education_required,
      match_score: Math.round(matchScore),
      skill_match: Math.round(skillMatch),
      interest_match: Math.round(interestMatch),
    });
  }

  // Sort by match score and return top 10
  careerMatches.sort((a, b) => b.match_score - a.match_score);
  const topMatches = careerMatches.slice(0, 10);

  return c.json(topMatches);
});

// Get detailed information about a specific career
app.get("/api/careers/:id", async (c) => {
  const careerId = c.req.param("id");
  const db = c.env.DB;

  // Get career details
  const career = await db.prepare(`
    SELECT id, title, description, category, salary_range, growth_outlook, education_required
    FROM careers WHERE id = ?
  `).bind(careerId).first();

  if (!career) {
    return c.json({ error: "Career not found" }, 404);
  }

  // Get career skills
  const skills = await db.prepare(`
    SELECT skill_name, importance FROM career_skills WHERE career_id = ? ORDER BY importance DESC
  `).bind(careerId).all();

  // Get career interests
  const interests = await db.prepare(`
    SELECT interest_name, importance FROM career_interests WHERE career_id = ? ORDER BY importance DESC
  `).bind(careerId).all();

  // Get career development steps
  const steps = await db.prepare(`
    SELECT step_order, title, description, timeframe FROM career_steps WHERE career_id = ? ORDER BY step_order
  `).bind(careerId).all();

  const careerDetail = {
    id: career.id,
    title: career.title,
    description: career.description,
    category: career.category,
    salary_range: career.salary_range,
    growth_outlook: career.growth_outlook,
    education_required: career.education_required,
    skills: skills.results,
    interests: interests.results,
    steps: steps.results,
  };

  return c.json(careerDetail);
});

export default app;
